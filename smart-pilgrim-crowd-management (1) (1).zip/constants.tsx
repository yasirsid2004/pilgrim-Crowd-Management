import React from 'react';
import { Language, Translations, CrowdDataPoint, QueueStatus, ZoneStatus } from './types';

export const MOCK_CROWD_DATA: CrowdDataPoint[] = [
  { time: '06:00', density: 15 },
  { time: '07:00', density: 25 },
  { time: '08:00', density: 40 },
  { time: '09:00', density: 60 },
  { time: '10:00', density: 75 },
  { time: '11:00', density: 85 },
  { time: '12:00', density: 80 },
];

export const MOCK_QUEUE_STATUS: QueueStatus[] = [
  { queueId: 'q1', name: 'General Darshan', waitTime: 120, status: 'filling_fast' },
  { queueId: 'q2', name: 'VIP Darshan', waitTime: 25, status: 'open' },
  { queueId: 'q3', name: 'Special Assistance', waitTime: 15, status: 'open' },
  { queueId: 'q4', name: 'Prasad Counter', waitTime: 45, status: 'closed' },
];

export const MOCK_ZONE_STATUS: ZoneStatus[] = [
    { id: 'main-temple', name: 'Main Temple', density: 88 },
    { id: 'queue-complex', name: 'Queue Complex', density: 72 },
    { id: 'prasad-hall', name: 'Prasad Hall', density: 55 },
    { id: 'parking', name: 'Parking Area', density: 95 },
    { id: 'ghat', name: 'River Ghat', density: 40 },
];

export const TRANSLATIONS: Translations = {
  // Header
  appTitle: { en: 'Smart Pilgrim Hub', hi: 'स्मार्ट तीर्थयात्री हब' },
  language: { en: 'Language', hi: 'भाषा' },
  english: { en: 'English', hi: 'अंग्रेज़ी' },
  hindi: { en: 'Hindi', hi: 'हिंदी' },
  
  // Dashboard
  dashboardTitle: { en: 'Live Dashboard', hi: 'लाइव डैशबोर्ड' },
  crowdDensityMap: { en: 'Crowd Density Map', hi: 'भीड़ घनत्व नक्शा' },
  queueStatus: { en: 'Queue Status', hi: 'कतार की स्थिति' },
  crowdAnalytics: { en: 'Crowd Analytics (Today)', hi: 'भीड़ विश्लेषण (आज)' },
  aiSafetyAlerts: { en: 'AI-Powered Safety Alerts', hi: 'एआई-संचालित सुरक्षा अलर्ट' },
  
  // Map Zones
  'Main Temple': { en: 'Main Temple', hi: 'मुख्य मंदिर' },
  'Queue Complex': { en: 'Queue Complex', hi: 'कतार परिसर' },
  'Prasad Hall': { en: 'Prasad Hall', hi: 'प्रसाद हॉल' },
  'Parking Area': { en: 'Parking Area', hi: 'पार्किंग क्षेत्र' },
  'River Ghat': { en: 'River Ghat', hi: 'नदी घाट' },

  // Queue Widget
  waitTime: { en: 'Wait Time', hi: 'प्रतीक्षा समय' },
  minutes: { en: 'min', hi: 'मिनट' },
  status: { en: 'Status', hi: 'स्थिति' },
  open: { en: 'Open', hi: 'खुला' },
  closed: { en: 'Closed', hi: 'बंद' },
  filling_fast: { en: 'Filling Fast', hi: 'तेजी से भर रहा है' },

  // Alerts
  generatingAlerts: { en: 'Generating insights from live data...', hi: 'लाइव डेटा से अंतर्दृष्टि उत्पन्न हो रही है...' },
  analysis: { en: 'AI Analysis', hi: 'एआई विश्लेषण' },
  alerts: { en: 'Alerts', hi: 'चेतावनी' },
  errorGenerating: { en: 'Error generating alerts.', hi: 'अलर्ट उत्पन्न करने में त्रुटि।'},
  
  // Ticket Booking
  bookDarshanTicket: { en: 'Book Darshan Ticket', hi: 'दर्शन टिकट बुक करें' },
  pilgrimName: { en: 'Pilgrim Name', hi: 'तीर्थयात्री का नाम' },
  numberOfPilgrims: { en: 'Number of Pilgrims', hi: 'तीर्थयात्रियों की संख्या' },
  selectDate: { en: 'Select Date', hi: 'दिनांक चुनें' },
  selectTimeSlot: { en: 'Select Time Slot', hi: 'समय स्लॉट चुनें' },
  bookNow: { en: 'Book Now', hi: 'अभी बुक करें' },
  ticketConfirmation: { en: 'Ticket Confirmation', hi: 'टिकट पुष्टि' },
  bookingSuccessful: { en: 'Booking Successful!', hi: 'बुकिंग सफल!' },
  ticketDetails: { en: 'Your Darshan ticket has been confirmed.', hi: 'आपका दर्शन टिकट कन्फर्म हो गया है।' },
  name: { en: 'Name', hi: 'नाम' },
  pilgrims: { en: 'Pilgrims', hi: 'तीर्थयात्री' },
  date: { en: 'Date', hi: 'दिनांक' },
  timeSlot: { en: 'Time Slot', hi: 'समय स्लॉट' },
  close: { en: 'Close', hi: 'बंद करें' },

  // Chart
  crowdDensity: {en: 'Crowd Density (%)', hi: 'भीड़ घनत्व (%)'},
};

export const getTranslation = (key: string, lang: Language): string => {
  return TRANSLATIONS[key]?.[lang] || key;
};

export const TempleMapSVG = () => (
    <svg viewBox="0 0 400 300" className="w-full h-full">
        <rect width="400" height="300" fill="#F3F4F6"/>
        <path id="ghat" d="M10 280 Q 200 320 390 280 L 390 295 Q 200 335 10 295 Z" fill="#3B82F6" opacity="0.5"/>
        <text x="180" y="295" fontSize="10" fill="#1E40AF">River Ghat</text>
        
        <rect id="parking" x="10" y="10" width="100" height="260" stroke="#9CA3AF" strokeWidth="1" />
        <text x="35" y="140" fontSize="12" fill="#374151">Parking</text>
        
        <rect id="queue-complex" x="120" y="150" width="150" height="120" stroke="#9CA3AF" strokeWidth="1" />
        <text x="160" y="210" fontSize="12" fill="#374151">Queue Complex</text>
        
        <rect id="prasad-hall" x="120" y="10" width="150" height="130" stroke="#9CA3AF" strokeWidth="1" />
        <text x="165" y="80" fontSize="12" fill="#374151">Prasad Hall</text>

        <path id="main-temple" d="M280 80 L 380 80 L 380 220 L 280 220 L 280 180 L 330 150 L 280 120 Z" stroke="#9CA3AF" strokeWidth="1" />
        <text x="310" y="155" fontSize="12" fill="#374151">Main Temple</text>
    </svg>
);