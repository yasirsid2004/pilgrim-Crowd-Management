
import { GoogleGenAI, Type } from "@google/genai";
import { ZoneStatus } from '../types';

if (!process.env.API_KEY) {
    console.warn("API_KEY environment variable not set. Using a mock response.");
}

const ai = process.env.API_KEY ? new GoogleGenAI({ apiKey: process.env.API_KEY }) : null;

interface GeminiResponse {
    analysis: string;
    alerts: {
        type: 'info' | 'warning' | 'critical';
        message: string;
    }[];
}

const mockResponse: GeminiResponse = {
    analysis: "Overall crowd levels are high, especially near the main temple and parking. The flow from the queue complex is steady but requires monitoring. The River Ghat area is currently underutilized.",
    alerts: [
        { type: 'critical', message: "Parking area at 95% capacity. Divert incoming traffic to auxiliary lot B." },
        { type: 'warning', message: "High density in the Main Temple sanctum. Advise pilgrims to keep moving and avoid lingering." },
        { type: 'info', message: "Queue for General Darshan is exceeding 2 hours. Consider opening additional lines." }
    ]
};

export const generateCrowdInsights = async (zones: ZoneStatus[]): Promise<GeminiResponse> => {
    if (!ai) {
        return new Promise(resolve => setTimeout(() => resolve(mockResponse), 1500));
    }
    
    try {
        const zoneDataString = zones.map(z => `${z.name}: ${z.density}%`).join(', ');
        const prompt = `You are a crowd management AI for a large pilgrim site. Based on the following real-time crowd density data, provide a brief overall analysis and 2-3 actionable safety alerts. Focus on critical issues like overcrowding, bottlenecks, and potential safety hazards. The data is: ${zoneDataString}.`;

        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        analysis: {
                            type: Type.STRING,
                            description: "A brief, insightful analysis of the overall crowd situation."
                        },
                        alerts: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    type: {
                                        type: Type.STRING,
                                        description: "The severity of the alert: 'info', 'warning', or 'critical'."
                                    },
                                    message: {
                                        type: Type.STRING,
                                        description: "A concise, actionable alert message."
                                    }
                                }
                            }
                        }
                    }
                }
            }
        });
        
        const jsonText = response.text.trim();
        return JSON.parse(jsonText);

    } catch (error) {
        console.error("Error calling Gemini API:", error);
        // Fallback to mock response on API error
        return mockResponse;
    }
};
   