
export enum Language {
  EN = 'en',
  HI = 'hi',
}

export interface CrowdDataPoint {
  time: string;
  density: number;
}

export interface QueueStatus {
  queueId: string;
  name: string;
  waitTime: number; // in minutes
  status: 'open' | 'closed' | 'filling_fast';
}

export interface ZoneStatus {
  id: string;
  name: string;
  density: number; // percentage
}

export interface Alert {
  id: string;
  type: 'info' | 'warning' | 'critical';
  message: string;
}

export interface Ticket {
    id: string;
    name: string;
    count: number;
    timeSlot: string;
    date: string;
}

export interface Translations {
  [key: string]: {
    [lang in Language]: string;
  };
}
   