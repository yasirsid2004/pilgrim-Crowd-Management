import React from 'react';
import { Language, ZoneStatus, QueueStatus, CrowdDataPoint, Ticket } from '../types';
import { getTranslation } from '../constants';
import { CrowdDensityMap } from './CrowdDensityMap';
import { QueueStatusWidget } from './QueueStatusWidget';
import { CrowdAnalyticsChart } from './CrowdAnalyticsChart';
import { SafetyAlerts } from './SafetyAlerts';
import { TicketBooking } from './TicketBooking';
import { Icon } from './Icon';

interface DashboardProps {
    language: Language;
    zones: ZoneStatus[];
    queues: QueueStatus[];
    crowdData: CrowdDataPoint[];
    onTicketBooked: (ticket: Ticket) => void;
}

interface WidgetProps {
  title: string;
  icon: 'map-pin' | 'clock' | 'chart' | 'bell' | 'ticket';
  children: React.ReactNode;
  className?: string;
}

const Widget: React.FC<WidgetProps> = ({ title, icon, children, className }) => (
    <div className={`bg-base-100 rounded-xl shadow-lg border border-gray-200/50 flex flex-col ${className}`}>
        <div className="p-4 border-b border-gray-200 flex items-center">
            <Icon icon={icon} className="w-6 h-6 text-primary mr-3" />
            <h3 className="text-lg font-bold text-gray-800">{title}</h3>
        </div>
        <div className="p-4 flex-grow relative">
            {children}
        </div>
    </div>
);

export const Dashboard: React.FC<DashboardProps> = (props) => {
    const { language, zones, queues, crowdData, onTicketBooked } = props;
    return (
        <main className="flex-grow container mx-auto p-4 sm:p-6 lg:p-8">
            <h2 className="text-3xl font-extrabold text-gray-900 mb-6">{getTranslation('dashboardTitle', language)}</h2>
            <div className="grid grid-cols-1 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                
                <Widget title={getTranslation('crowdDensityMap', language)} icon="map-pin" className="lg:col-span-2 xl:col-span-2 row-span-2">
                    <CrowdDensityMap zones={zones} language={language} />
                </Widget>
                
                <Widget title={getTranslation('queueStatus', language)} icon="clock" className="xl:col-span-2">
                    <QueueStatusWidget queues={queues} language={language} />
                </Widget>
                
                <Widget title={getTranslation('crowdAnalytics', language)} icon="chart" className="">
                    <CrowdAnalyticsChart language={language} />
                </Widget>
                
                <Widget title={getTranslation('aiSafetyAlerts', language)} icon="bell" className="lg:col-span-1 xl:col-span-2">
                   <SafetyAlerts language={language} />
                </Widget>

                <Widget title={getTranslation('bookDarshanTicket', language)} icon="ticket" className="lg:col-span-2 xl:col-span-2">
                    <TicketBooking language={language} onTicketBooked={onTicketBooked} />
                </Widget>
            </div>
        </main>
    );
}