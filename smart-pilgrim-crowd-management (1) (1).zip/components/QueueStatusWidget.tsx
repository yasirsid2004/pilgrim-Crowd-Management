
import React from 'react';
import { QueueStatus, Language } from '../types';
import { getTranslation } from '../constants';
import { Icon } from './Icon';

interface QueueStatusWidgetProps {
  queues: QueueStatus[];
  language: Language;
}

const getStatusClasses = (status: QueueStatus['status']) => {
    switch (status) {
        case 'open':
            return 'bg-green-100 text-green-800';
        case 'closed':
            return 'bg-red-100 text-red-800';
        case 'filling_fast':
            return 'bg-yellow-100 text-yellow-800 animate-pulse-fast';
        default:
            return 'bg-gray-100 text-gray-800';
    }
}

export const QueueStatusWidget: React.FC<QueueStatusWidgetProps> = ({ queues, language }) => {
  return (
    <div className="space-y-3 h-full overflow-y-auto">
      {queues.map(queue => (
        <div key={queue.queueId} className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 flex items-center justify-between">
            <div>
                <p className="font-bold text-gray-800">{queue.name}</p>
                <div className={`mt-2 text-xs font-medium mr-2 px-2.5 py-0.5 rounded-full inline-block ${getStatusClasses(queue.status)}`}>
                    {getTranslation(queue.status, language)}
                </div>
            </div>
            <div className="text-right">
                <p className="text-sm text-gray-500">{getTranslation('waitTime', language)}</p>
                <p className="text-2xl font-extrabold text-primary">{queue.waitTime} <span className="text-lg font-medium text-gray-600">{getTranslation('minutes', language)}</span></p>
            </div>
        </div>
      ))}
    </div>
  );
};
   