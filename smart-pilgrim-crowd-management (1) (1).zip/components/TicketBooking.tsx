
import React, { useState } from 'react';
import { Language, Ticket } from '../types';
import { getTranslation } from '../constants';
import { Icon } from './Icon';
import { Modal } from './Modal';

interface TicketBookingProps {
    language: Language;
    onTicketBooked: (ticket: Ticket) => void;
}

export const TicketBooking: React.FC<TicketBookingProps> = ({ language, onTicketBooked }) => {
    const [name, setName] = useState('');
    const [count, setCount] = useState(1);
    const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
    const [timeSlot, setTimeSlot] = useState('09:00 - 10:00');
    
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [confirmedTicket, setConfirmedTicket] = useState<Ticket | null>(null);

    const timeSlots = [
        '06:00 - 07:00', '07:00 - 08:00', '08:00 - 09:00', '09:00 - 10:00',
        '10:00 - 11:00', '11:00 - 12:00', '14:00 - 15:00', '15:00 - 16:00',
        '16:00 - 17:00', '17:00 - 18:00',
    ];

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const newTicket: Ticket = {
            id: `T${Date.now()}`,
            name,
            count,
            date,
            timeSlot
        };
        onTicketBooked(newTicket);
        setConfirmedTicket(newTicket);
        setIsModalOpen(true);
        // Reset form
        setName('');
        setCount(1);
    };

    const closeModal = () => {
        setIsModalOpen(false);
        setConfirmedTicket(null);
    }

    return (
        <>
        <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label htmlFor="pilgrimName" className="block text-sm font-medium text-gray-700">{getTranslation('pilgrimName', language)}</label>
                    <input type="text" id="pilgrimName" value={name} onChange={e => setName(e.target.value)} required className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"/>
                </div>
                <div>
                    <label htmlFor="numberOfPilgrims" className="block text-sm font-medium text-gray-700">{getTranslation('numberOfPilgrims', language)}</label>
                    <input type="number" id="numberOfPilgrims" value={count} onChange={e => setCount(parseInt(e.target.value, 10))} min="1" max="10" required className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"/>
                </div>
                <div>
                    <label htmlFor="selectDate" className="block text-sm font-medium text-gray-700">{getTranslation('selectDate', language)}</label>
                    <input type="date" id="selectDate" value={date} onChange={e => setDate(e.target.value)} min={new Date().toISOString().split('T')[0]} required className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"/>
                </div>
                <div>
                    <label htmlFor="selectTimeSlot" className="block text-sm font-medium text-gray-700">{getTranslation('selectTimeSlot', language)}</label>
                    <select id="selectTimeSlot" value={timeSlot} onChange={e => setTimeSlot(e.target.value)} required className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm">
                        {timeSlots.map(slot => <option key={slot} value={slot}>{slot}</option>)}
                    </select>
                </div>
            </div>
            <button type="submit" className="w-full flex justify-center items-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-primary-content bg-primary hover:bg-primary-focus focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-focus transition-colors">
                <Icon icon="ticket" className="w-5 h-5 mr-2"/>
                {getTranslation('bookNow', language)}
            </button>
        </form>

        <Modal isOpen={isModalOpen} onClose={closeModal} title={getTranslation('ticketConfirmation', language)}>
            {confirmedTicket && (
                <div className="space-y-4">
                    <div className="text-center">
                        <svg className="mx-auto h-12 w-12 text-success" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <h3 className="mt-2 text-lg leading-6 font-medium text-gray-900">{getTranslation('bookingSuccessful', language)}</h3>
                        <p className="mt-1 text-sm text-gray-500">{getTranslation('ticketDetails', language)}</p>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-lg border border-gray-200 text-sm">
                        <div className="flex justify-between py-1"><span className="font-semibold text-gray-600">{getTranslation('name', language)}:</span><span>{confirmedTicket.name}</span></div>
                        <div className="flex justify-between py-1"><span className="font-semibold text-gray-600">{getTranslation('pilgrims', language)}:</span><span>{confirmedTicket.count}</span></div>
                        <div className="flex justify-between py-1"><span className="font-semibold text-gray-600">{getTranslation('date', language)}:</span><span>{new Date(confirmedTicket.date).toLocaleDateString()}</span></div>
                        <div className="flex justify-between py-1"><span className="font-semibold text-gray-600">{getTranslation('timeSlot', language)}:</span><span>{confirmedTicket.timeSlot}</span></div>
                    </div>
                    <button onClick={closeModal} className="w-full mt-4 py-2 px-4 bg-primary text-primary-content rounded-md hover:bg-primary-focus focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary">
                        {getTranslation('close', language)}
                    </button>
                </div>
            )}
        </Modal>
        </>
    );
};
   