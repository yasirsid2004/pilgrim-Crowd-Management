import React from 'react';
import { Alert as AlertType, Language } from '../types';
import { getTranslation } from '../constants';
import { Icon } from './Icon';

interface SafetyAlertsProps {
  language: Language;
}

const Alert: React.FC<{ type: AlertType['type'], message: string }> = ({ type, message }) => {
  const baseClasses = "flex items-start p-3 rounded-lg border-l-4";
  const typeClasses = {
    info: 'bg-blue-50 border-blue-500 text-blue-800',
    warning: 'bg-yellow-50 border-yellow-500 text-yellow-800',
    critical: 'bg-red-50 border-red-500 text-red-800',
  };
  const icon: 'info' | 'warning' | 'critical' = type;
  
  return (
    <div className={`${baseClasses} ${typeClasses[type]}`}>
      <Icon icon={icon} className="w-5 h-5 mr-3 flex-shrink-0 mt-0.5" />
      <p className="text-sm">{message}</p>
    </div>
  );
};

const MOCK_INSIGHTS = {
    analysis: "Overall crowd levels are high, especially near the main temple and parking. The flow from the queue complex is steady but requires monitoring. The River Ghat area is currently underutilized.",
    alerts: [
        { id: 'alert-1', type: 'critical' as const, message: "Parking area at 95% capacity. Divert incoming traffic to auxiliary lot B." },
        { id: 'alert-2', type: 'warning' as const, message: "High density in the Main Temple sanctum. Advise pilgrims to keep moving and avoid lingering." },
        { id: 'alert-3', type: 'info' as const, message: "Queue for General Darshan is exceeding 2 hours. Consider opening additional lines." }
    ]
};

export const SafetyAlerts: React.FC<SafetyAlertsProps> = ({ language }) => {

  return (
    <div className="space-y-4 h-full overflow-y-auto pr-2">
      <div>
        <h4 className="font-semibold text-gray-700 mb-2">{getTranslation('analysis', language)}</h4>
        <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded-lg border">{MOCK_INSIGHTS.analysis}</p>
      </div>
      <div>
        <h4 className="font-semibold text-gray-700 mb-2">{getTranslation('alerts', language)}</h4>
        <div className="space-y-2">
          {MOCK_INSIGHTS.alerts.map(alert => <Alert key={alert.id} type={alert.type} message={alert.message} />)}
        </div>
      </div>
    </div>
  );
};