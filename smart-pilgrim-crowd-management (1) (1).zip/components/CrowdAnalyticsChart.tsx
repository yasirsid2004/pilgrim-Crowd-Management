import React from 'react';
import { Language } from '../types';
import { getTranslation } from '../constants';
import { Icon } from './Icon';

interface CrowdAnalyticsChartProps {
  language: Language;
}

export const CrowdAnalyticsChart: React.FC<CrowdAnalyticsChartProps> = ({ language }) => {
  return (
    <div className="w-full h-full flex flex-col items-center justify-center text-center bg-gray-50 rounded-lg p-4 min-h-[200px]">
        <Icon icon="chart" className="w-12 h-12 text-gray-300 mb-4" />
      <h4 className="font-semibold text-gray-600">
        {getTranslation('crowdAnalytics', language)}
      </h4>
      <p className="text-sm text-gray-400 mt-1">
        Live chart data is temporarily unavailable.
      </p>
    </div>
  );
};