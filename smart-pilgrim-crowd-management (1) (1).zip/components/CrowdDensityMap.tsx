
import React, { useEffect } from 'react';
import { ZoneStatus, Language } from '../types';
import { TempleMapSVG, getTranslation } from '../constants';
import { Icon } from './Icon';

interface CrowdDensityMapProps {
  zones: ZoneStatus[];
  language: Language;
}

const getDensityColor = (density: number): string => {
  if (density > 90) return 'fill-red-600';
  if (density > 75) return 'fill-orange-500';
  if (density > 50) return 'fill-yellow-400';
  return 'fill-green-500';
};

export const CrowdDensityMap: React.FC<CrowdDensityMapProps> = ({ zones, language }) => {

  useEffect(() => {
    zones.forEach(zone => {
      const el = document.getElementById(zone.id);
      if (el) {
        el.setAttribute('class', `${getDensityColor(zone.density)} transition-colors duration-500`);
      }
    });
  }, [zones]);
  
  return (
    <div className="h-full flex flex-col lg:flex-row gap-4">
      <div className="lg:w-2/3 h-64 lg:h-full bg-white p-2 rounded-lg shadow-sm border border-gray-200">
        <TempleMapSVG />
      </div>
      <div className="lg:w-1/3 space-y-3">
        {zones.map(zone => (
          <div key={zone.id} className="bg-white p-3 rounded-lg shadow-sm border border-gray-200 flex items-center justify-between">
            <div>
              <p className="font-semibold text-gray-700">{getTranslation(zone.name, language)}</p>
              <p className="text-sm text-gray-500 flex items-center">
                 <Icon icon="users" className="w-4 h-4 mr-1"/> {getTranslation('crowdDensity', language)}
              </p>
            </div>
            <div className="flex items-center space-x-2">
                <div className="w-16 bg-gray-200 rounded-full h-2.5">
                    <div className={`${getDensityColor(zone.density).replace('fill-', 'bg-')} h-2.5 rounded-full`} style={{width: `${zone.density}%`}}></div>
                </div>
                <span className={`font-bold text-lg ${getDensityColor(zone.density).replace('fill-','text-')}`}>
                    {zone.density}%
                </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
   