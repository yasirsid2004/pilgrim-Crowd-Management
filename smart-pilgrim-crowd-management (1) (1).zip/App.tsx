
import React, { useState, useEffect } from 'react';
import { Language, ZoneStatus, QueueStatus, CrowdDataPoint, Ticket } from './types';
import { MOCK_ZONE_STATUS, MOCK_QUEUE_STATUS, MOCK_CROWD_DATA } from './constants';
import { Header } from './components/Header';
import { Dashboard } from './components/Dashboard';

const App: React.FC = () => {
    const [language, setLanguage] = useState<Language>(Language.EN);
    const [zones, setZones] = useState<ZoneStatus[]>(MOCK_ZONE_STATUS);
    const [queues, setQueues] = useState<QueueStatus[]>(MOCK_QUEUE_STATUS);
    const [tickets, setTickets] = useState<Ticket[]>([]);

    // Simulate real-time data updates
    useEffect(() => {
        const interval = setInterval(() => {
            setZones(prevZones =>
                prevZones.map(zone => ({
                    ...zone,
                    density: Math.max(10, Math.min(100, zone.density + Math.floor(Math.random() * 7) - 3))
                }))
            );
            setQueues(prevQueues =>
                prevQueues.map(queue => ({
                    ...queue,
                    waitTime: Math.max(10, queue.waitTime + Math.floor(Math.random() * 5) - 2)
                }))
            );
        }, 3000); // Update every 3 seconds

        return () => clearInterval(interval);
    }, []);
    
    const handleTicketBooked = (ticket: Ticket) => {
        setTickets(prevTickets => [...prevTickets, ticket]);
        console.log("New Ticket Booked:", ticket);
    };

    return (
        <div className="min-h-screen bg-base-200 font-sans">
            <Header language={language} setLanguage={setLanguage} />
            <Dashboard 
                language={language}
                zones={zones}
                queues={queues}
                crowdData={MOCK_CROWD_DATA}
                onTicketBooked={handleTicketBooked}
            />
            <footer className="text-center py-4 text-sm text-gray-500">
                <p>&copy; {new Date().getFullYear()} Smart Pilgrim Crowd Management System. All rights reserved.</p>
            </footer>
        </div>
    );
};

export default App;
   